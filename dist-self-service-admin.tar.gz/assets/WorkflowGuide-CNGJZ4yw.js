const o=()=>null;export{o as W};
