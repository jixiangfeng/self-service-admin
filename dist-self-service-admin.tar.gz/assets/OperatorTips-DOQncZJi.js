const l=()=>null,o=()=>null;export{l as C,o as O};
